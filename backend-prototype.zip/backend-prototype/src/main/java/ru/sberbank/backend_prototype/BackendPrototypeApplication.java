package ru.sberbank.backend_prototype;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendPrototypeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendPrototypeApplication.class, args);
	}

}
